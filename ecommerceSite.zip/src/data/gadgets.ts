export const gadgets = `[
  {
    "id": 50,
    "title": "ROBOT SKY SPACE STARS LIGHT ASTRONAUT GALAXY PROJECTOR, NIGHT LAMP, BEDROOM, KIDS, PROJECTOR, REMOTE CONTROL, STAR PROJECTOR WILL TAKE CHILDREN'S TO EXPLORE THE VAST STARRY SKY FOR ADULTS, RAKSHA BANDHAN, DIWALI GIFT",
    "price": 200,
    "description": "starry sky projector will create colorful, unpredictable nebulae and lifelike dreams, high-definition starlight galaxies and lightly twinkling stars, as well as a combination of multiple colors, remind you of under the stars The most relaxing night. It can be switched by remote control or buttons.",
    "category": "gadgets",
    "image": "https://deodap.in/cdn/shop/files/3_f271d3d6-e000-4533-86d1-4a384d50e99f_1500x1500.jpg?v=1708255009",
    "rating": {
      "rate": 3.9,
      "count": 120
    }
  },
  {
    "id": 51,
    "title": "COLOUR CHANGING GOOD NIGHT STAR MASTER ROTATING PROJECTION NIGHT LAMP",
    "price": 80,
    "description": "This night light is a perfect gift for a kid's bedroom. It is also ideal for decorating events with colorful projected stars. For instance, you can use it to decorate a wedding, birthday party, or even use it during Christmas. You can also use it as a romantic night lamp or as a decorative night light lamp, Galaxy Night.",
    "category": "gadgets",
    "image": "https://deodap.in/cdn/shop/products/WhatsAppImage2020-09-21at1.48.51PM_959x959.jpg?v=1686905500",
    "rating": {
      "rate": 3.9,
      "count": 120
    }
  },
  {
    "id": 52,
    "title": "SOLAR MULTI-FUNCTIONAL EMERGENCY LED LIGHT BULB WITH USB CHARGING, LED CAMPING LAMP, CAMPING LAMP, USB RECHARGEABLE, 5 BRIGHTNESS LIGHT MODES, FOLDABLE CAMPING LIGHT, SOS IP65 WATERPROOF CAMPING LIGHT, BLACKOUT EMERGENCY EQUIPMENT, CAMPING GADGETS",
    "price": 100,
    "description": "The LED light can be placed on the desk or hung on the top and can be used as camping light, tent light, work light, reading light, greenhouse light, shed light, emergency light in case of power failure, etc.",
    "category": "gadgets",
    "image": "https://deodap.in/cdn/shop/files/03_ab7ab737-b2fb-4a35-bab9-1352b3441ef5_700x700.jpg?v=1705040472",
    "rating": {
      "rate": 3.9,
      "count": 120
    }
  },
  {
    "id": 53,
    "title": "ROMANTIC CRYSTAL TABLE LAMP, DIAMOND LAMP, 16 COLORS, 6 BRIGHTNESS LEVEL, TOUCH / REMOTE CONTROL SWITCH, SUB CHARGING, LAMPSHADE NIGHT LIGHT, BEDROOM BEDSIDE, LIVING ROOM DECORATION",
    "price": 120,
    "description": "The crystal bedside table lamp adopts touch control switch and provides 16 color choices Our table lamps have 16 color options, Diamond table lamp also comes with a remote control, which can switch 16 colors, brightness and multiple modes at will.",
    "category": "gadgets",
    "image": "https://deodap.in/cdn/shop/files/01_0413d227-7a9a-44b2-8a78-fbf0c5c8e90a_700x700.jpg?v=1716786830",
    "rating": {
      "rate": 3.9,
      "count": 120
    }
  },
  {
    "id": 54,
    "title": "CRYSTAL TOUCH NIGHT LIGHT (16 COLORS) - ROSE DIAMOND TABLE LAMP WITH REMOTE CONTROL, USB TABLE LAMP, ROMANTIC DATE LIGHTING DECOR FOR FESTIVAL, BEDROOM, DINING ROOM",
    "price": 140,
    "description": "Turn on this table lamp, the 3D visual effect is like a rose blooming on the table, the square cut refracts the light and shadow like a diamond, the rose shape reflects the shadow, a charming Showing light and shadow effects. This crystal table lamp is simple, luxurious, comfortable, and romantic. Suitable for family, balcony, party, bar, table decoration.",
    "category": "gadgets",
    "image": "https://deodap.in/cdn/shop/files/01_5dc1ba88-8421-4633-9576-e85cf3eaaee3_700x700.jpg?v=1716981958",
    "rating": {
      "rate": 3.9,
      "count": 120
    }
  }
  
]
`;
