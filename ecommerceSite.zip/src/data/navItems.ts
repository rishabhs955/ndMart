export const navData = [
  { id: 0, name: "All", value: "all", to: "all-products" },
  { id: 1, name: "Men", value: "Men", to: "men" },
  { id: 2, name: "Women", value: "Women", to: "women" },
  { id: 3, name: "Gadgets", value: "Gadgets", to: "gadgets" },
  { id: 4, name: "Jewelery", value: "Jewelery", to: "jewelry" },
];
export const sizeData = ["XS", "SM", "M", "L", "XL", "XXL"];
