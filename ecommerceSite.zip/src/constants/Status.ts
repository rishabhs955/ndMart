export const STATUS = Object.freeze({
    IDLE: "idle",
    LOADING: "loading",
    ERROR: "error",
  });