export const ROUTES = [
  {
    name: "All",
    url: "products",
  },
  {
    name: "Men",
    url: "men's clothing",
  },
  {
    name: "Women",
    url: "women's clothing",
  },
  {
    name: "Electronics",
    url: "electronics",
  },
  {
    name: "Jewelery",
    url: "jewelery",
  },
];
